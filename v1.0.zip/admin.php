<?php 
include_once('nav.php');
include_once('connection.php');

if (isset($_POST['findUser'])) {
	$email = $_POST['searchEmail'];
	
	try {
        $sql = "SELECT * FROM `accounts` WHERE `email` = '$email'";
        $result = $db->query($sql);
		echo "User found";
    } catch(PDOException $e) {
        echo "'ruh roh' - scooby doo";
    }
    $database->close(); 
}
else if (isset($_POST['updateUser'])) {
	  
	$database = new Connection();
    $db = $database->open();
	
	$firstName = $_POST['firstName'];
	$lastName = $_POST['lastName'];
	$email = $_POST['email'];
	$monthly = $_POST['monthly'];
	$breaking = $_POST['breaking'];
	}	

    try {
        $sql = "UPDATE `accounts` SET `firstName` = '$firstName', `familyName` = '$familyName', `email` = '$email', `monthly` = '$monthly', `breaking` = '$breaking'";
        $result = $db->query($sql);
		echo "User details updated";
    } catch(PDOException $e) {
        echo "'ruh roh' - scooby doo";
    }
    $database->close(); 
  }
?>

<!DOCTYPE html>

<!--
 * James Boyd 
 * 30041547
 * 7/11/2022
-->

<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<title>Admin</title>
	<link rel="stylesheet" type="text/css" href="index_files/style.css">
	<meta charset="utf-8">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<style>
.error {color: #FF0000;}
</style>
<body>
<h2>Find User by Email</h2>
<form method="post" action="">
  E-mail: <input type="text" name="searchEmail">
  <br><br>
  <input type="submit" name="findUser" value="Find User">
</form>

<br><br>

<form method="post" action="">
  First Name: <input type="text" name="firstName">
  <br><br>
  Family Name: <input type="text" name="familyName">
  <br><br>
  E-mail: <input type="text" name="email">
  <br><br>
  Subscriptions:
  <br>
  Monthly Newsletter:
  <input type="radio" name="newsletter" value="true">Yes
  <input type="radio" name="newsletter" value="false">No
  <br>
  Breaking News:
  <input type="radio" name="breaking" value="true">Yes
  <input type="radio" name="breaking" value="false">No
  <br><br>
  <input type="submit" name="updateUser" value="Update User">
</form>

</body>
</html>